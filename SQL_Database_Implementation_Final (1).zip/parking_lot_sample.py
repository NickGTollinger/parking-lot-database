import sqlite3
import random
import csv
import pandas as pd
import datetime
#Please note that for this program to work, you need to install pandas and use a compatible version of Python. Please also use the database file provided.

#Declare global variables for connecting to the database file and a cursor to traverse the database
database = sqlite3.connect("parking_lot_database.db")
cursor = database.cursor()
#Every lot will need a unique instance of capacity for every type of parking spot
class Lots:
    #When a new Lots object is created with the following parameters, store those parameters so that our methods may use them to insert data
    def __init__(self, lot, time, total_capacity, green_capacity, gold_capacity, orange_capacity, purple_capacity, pay_capacity):
        self.lot = lot
        self.time = time
        self.total_capacity = total_capacity
        self.green_capacity = green_capacity
        self.gold_capacity = gold_capacity
        self.orange_capacity = orange_capacity
        self.purple_capacity = purple_capacity
        self.pay_capacity = pay_capacity
    
    #Method to insert newly generated data into the database
    def insertData(self):
        cursor.execute("INSERT INTO lot_" + str(self.lot) + " VALUES (?, ?, ?, ?, ?, ?, ?)",
                (self.time, self.total_capacity, self.green_capacity, self.gold_capacity,
                 self.orange_capacity, self.purple_capacity, self.pay_capacity))
        database.commit()
    
    #Method to show user the history of a lot's capacity, uses pandas to format the table data in a clean manner
    def displayData(self):
        print(pd.read_sql_query("SELECT * FROM lot_" + str(self.lot), database))

#This method is used to generate a random time associated with each lot update. Time range is October 15th of this year to November 15th. Returns the time value.
def timePrint():
    start = datetime.datetime(2023, 10, 15, 00)
    current = start
    current = current + datetime.timedelta(minutes=random.randrange(43200))
    return current

def main():
    
    #Declare a list of all possible lot types
    lot_type = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W']

    #Create a table for each lot if it doesn't already exist
    for i in lot_type:
        cursor.execute("CREATE TABLE IF NOT EXISTS lot_" + str(i) + " (Time, Total Capacity, Green Capacity, Gold Capacity, Orange Capacity, Purple Capacity, [Pay-By-Space Capacity])")
        database.commit()

    user_input = input("\nHello user, enter 1 if you'd like to view lot capacities, or enter 2 if you'd like to convert a SQL table into a .csv file for use in statistical analysis\n")
    if (user_input == '2'):
        user_input = input("Enter a Lot ranging from Lot A to J, M to N, or P to W to convert it into a .csv file: ")
        if (user_input in lot_type):
            lot = "lot_" + user_input
            data = cursor.execute("SELECT * FROM " + lot)
            f = open("output.csv", "w")
            with open ("output.csv", "w", newline='') as f:
                writer = csv.writer(f)
                writer.writerow((["Time", "Total Capacity", "Green Capacity", "Gold Capacity", "Orange Capacity", "Purple Capacity", "Pay-By-Space Capacity"]))
                writer.writerows(data)
            print("\nLot successfully converted! Exiting program")
            return
        else:
            print("\nInvalid input, exiting program")
            return

    elif (user_input != '1'):
        print("\nInvalid character entered, exiting program")
        return

    #Request the user for a valid lot
    user_input = input("Hello user, please enter a Lot ranging from Lot A to Lot J, Lot M to N, or Lot P to Lot W: ")

    #From here, I referred to the UTD parking map which shows whether a parking lot has a particular colored space. I picked a maximum capacity for each table and then let it generate a random value from 0 to that maximum
    #This randomness is meant to display how parking lots will vary in their capacities throughout the day. This program is just meant as a simulation of how adding to and displaying our database would work
    #Parking spot colors that are permanently set to 0 indicate that that particular parking spot does not exist in that lot
    #Each lot has its own unique ranges of possible values
    #Time values are generated each time a user requests lot data
    if (user_input == 'A'):
        #Set a variable to store which lot we're looking at
        lot = 'A'
        time = timePrint()
        #Set variables for each type of parking spot, they randomize between a minimum and maximum range that is based on the parking map and an estimate of the maximum capacity per colored parking spot
        green_capacity = random.randint(0, 200)
        gold_capacity = random.randint(0, 100)
        orange_capacity = random.randint(0, 35)
        purple_capacity = random.randint(0, 15)

        #Set total capacity
        total_capacity = green_capacity + gold_capacity + orange_capacity + purple_capacity 

        #Declare a new instance of Lot class, insert the data into the correct table, and then display the full lot history of the table, where the bottom value is the most recently added data
        lot_A = Lots(lot, time, total_capacity, green_capacity, gold_capacity, orange_capacity, purple_capacity, 0)
        lot_A.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_A.displayData()
    
    #From here the same process repeats as above, just for a different lot
    elif (user_input == 'B'):
        lot = 'B'
        time = timePrint()
        green_capacity = random.randint(0, 150)
        gold_capacity = random.randint(0, 25)
        orange_capacity = random.randint(0, 50)
        total_capacity = green_capacity + gold_capacity + orange_capacity
        lot_B = Lots(lot, time, total_capacity, green_capacity, gold_capacity, orange_capacity, 0, 0)
        lot_B.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_B.displayData()
 
    elif (user_input == 'C'):
        lot = 'C'
        time = timePrint()
        green_capacity = random.randint(0, 50)
        gold_capacity = random.randint(0, 50)
        orange_capacity = random.randint(0, 30)
        total_capacity = green_capacity + gold_capacity + orange_capacity
        lot_C = Lots(lot, time, total_capacity, green_capacity, gold_capacity, orange_capacity, 0, 0)
        lot_C.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_C.displayData()

    elif (user_input == 'D'):
        lot = 'D'
        time = timePrint()
        green_capacity = random.randint(0, 65)
        gold_capacity = random.randint(0, 35)
        total_capacity = green_capacity + gold_capacity
        lot_D = Lots(lot, time, total_capacity, green_capacity, gold_capacity, 0, 0, 0)
        lot_D.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_D.displayData()
  
    elif (user_input == 'E'):
        lot = 'E'
        time = timePrint()
        gold_capacity = random.randint(0, 15)
        orange_capacity = random.randint(0, 40)
        purple_capacity = random.randint(0, 15)
        total_capacity = gold_capacity + orange_capacity + purple_capacity
        lot_E = Lots(lot, time, total_capacity, 0, gold_capacity, orange_capacity, purple_capacity, 0)
        lot_E.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_E.displayData()
   
    elif (user_input == 'F'):
        lot = 'F'
        time = timePrint()
        pay_capacity = random.randint(0, 30)
        total_capacity = pay_capacity
        lot_F = Lots(lot, time, total_capacity, 0, 0, 0, 0, pay_capacity)
        lot_F.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_F.displayData()
    
    elif(user_input == 'G'):
        lot = 'G'
        time = timePrint()
        purple_capacity = 50
        total_capacity = purple_capacity
        lot_G = Lots(lot, time, total_capacity, 0, 0, 0, purple_capacity, 0)
        lot_G.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_G.displayData()
    
    elif(user_input == 'H'):
        lot = 'H'
        time = timePrint()
        green_capacity = random.randint(0, 20)
        gold_capacity = random.randint(0, 100)
        orange_capacity = random.randint(0, 75)
        purple_capacity = random.randint(0, 10)
        total_capacity = green_capacity + gold_capacity + orange_capacity + purple_capacity
        lot_H = Lots(lot, time, total_capacity, green_capacity, gold_capacity, orange_capacity, purple_capacity, 0)
        lot_H.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_H.displayData()
    
    elif(user_input == 'I'):
        lot = 'I'
        time = timePrint()
        gold_capacity = random.randint(0, 10)
        orange_capacity = random.randint(0, 15)
        purple_capacity = random.randint(0, 3)
        total_capacity = gold_capacity + orange_capacity + purple_capacity
        lot_I = Lots(lot, time, total_capacity, 0, gold_capacity, orange_capacity, purple_capacity, 0)
        lot_I.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_I.displayData()

    elif(user_input == 'J'):
        lot = 'J'
        time = timePrint()
        gold_capacity = random.randint(0, 125)
        orange_capacity = random.randint(0, 40)
        purple_capacity = random.randint(0, 15)
        total_capacity = gold_capacity + orange_capacity + purple_capacity
        lot_J = Lots(lot, time, total_capacity, 0, gold_capacity, orange_capacity, purple_capacity, 0)
        lot_J.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_J.displayData()
    
    elif (user_input == 'M'):
        lot = 'M'
        time = timePrint()
        gold_capacity = random.randint(0, 80)
        orange_capacity = random.randint(0, 60)
        purple_capacity = random.randint(0, 20)
        total_capacity = gold_capacity + orange_capacity + purple_capacity
        lot_M = Lots(lot, time, total_capacity, 0, gold_capacity, orange_capacity, purple_capacity, 0)
        lot_M.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_M.displayData()
    
    elif(user_input == 'N'):
        lot = 'N'
        time = timePrint()
        gold_capacity = random.randint(0, 10)
        orange_capacity = random.randint(0, 15)
        purple_capacity = random.randint(0, 2)
        total_capacity = gold_capacity + orange_capacity + purple_capacity
        lot_N = Lots(lot, time, total_capacity, 0, gold_capacity, orange_capacity, purple_capacity, 0)
        lot_N.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_N.displayData()

    elif(user_input == 'P'):
        lot = 'P'
        time = timePrint()
        gold_capacity = random.randint(0, 35)
        orange_capacity = random.randint(0, 25)
        purple_capacity = random.randint(0, 5)
        total_capacity = gold_capacity + orange_capacity + purple_capacity
        lot_P = Lots(lot, time, total_capacity, 0, gold_capacity, orange_capacity, purple_capacity, 0)
        lot_P.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_P.displayData()

    elif(user_input == 'Q'):
        lot = 'Q'
        time = timePrint()
        gold_capacity = random.randint(0, 20)
        orange_capacity = random.randint(0, 75)
        purple_capacity = random.randint(0, 25)
        total_capacity = gold_capacity + orange_capacity + purple_capacity
        lot_Q = Lots(lot, time, total_capacity, 0, gold_capacity, orange_capacity, purple_capacity, 0)
        lot_Q.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_Q.displayData()
    
    elif(user_input == 'R'):
        lot = 'R'
        time = timePrint()
        total_capacity = random.randint(0, 30)
        lot_R = Lots(lot, time, total_capacity, 0, 0, 0, 0, 0)
        lot_R.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_R.displayData()

    elif(user_input == 'S'):
        lot = 'S'
        time = timePrint()
        green_capacity = random.randint(0, 20)
        gold_capacity = random.randint(0, 5)
        orange_capacity = random.randint(0, 5)
        purple_capacity = random.randint(0, 3)
        total_capacity = green_capacity + gold_capacity + orange_capacity + purple_capacity
        lot_S = Lots(lot, time, total_capacity, green_capacity, gold_capacity, orange_capacity, purple_capacity, 0)
        lot_S.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_S.displayData()

    elif(user_input == 'T'):
        lot = 'T'
        time = timePrint()
        green_capacity = random.randint(0, 75)
        gold_capacity = random.randint(0, 55)
        orange_capacity = random.randint(0, 30)
        purple_capacity = random.randint(0, 3)
        total_capacity = green_capacity + gold_capacity + orange_capacity + purple_capacity
        lot_T = Lots(lot, time, total_capacity, green_capacity, gold_capacity, orange_capacity, purple_capacity, 0)
        lot_T.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_T.displayData()

    elif(user_input == 'U'):
        lot = 'U'
        time = timePrint()
        green_capacity = random.randint(0, 300)
        total_capacity = green_capacity
        lot_U = Lots(lot, time, total_capacity, green_capacity, 0, 0, 0, 0, 0)
        lot_U.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_U.displayData()

    elif(user_input == 'V'):
        lot = 'V'
        time = timePrint()
        green_capacity = random.randint(0, 75)
        gold_capacity = random.randint(0, 30)
        orange_capacity = random.randint(0, 8)
        total_capacity = green_capacity + gold_capacity + orange_capacity
        lot_V = Lots(lot, time, total_capacity, green_capacity, gold_capacity, orange_capacity, 0, 0)
        lot_V.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_V.displayData()
    
    elif(user_input == 'W'):
        lot = 'W'
        time = timePrint()
        green_capacity = random.randint(0, 20)
        gold_capacity = random.randint(0, 10)
        orange_capacity = random.randint(0, 2)
        purple_capacity = random.randint(0, 6)
        total_capacity = green_capacity + gold_capacity + orange_capacity + purple_capacity + random.randint(30)
        lot_W = Lots(lot, time, total_capacity, green_capacity, gold_capacity, orange_capacity, purple_capacity, 0)
        lot_W.insertData()
        print("\nNow displaying lot capacity history. Please note that a total capacity greater than the sum of lots indicates that there are parking spots present that are not green, gold, orange, purple, or pay-by-space.\n")
        print("Lot " + lot)
        lot_W.displayData()

    #Terminate the program if no valid lot is entered
    else:
        print("User did not enter a valid Lot, exiting program")
    
    cursor.close()
    database.close()
    return 0

main()


